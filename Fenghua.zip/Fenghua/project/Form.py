from Text import Text
from Image import Image
import OCR

import cv2
import time


class Form:
    def __init__(self, img_file_name, detection_method):
        self.detection_method = detection_method
        self.img_file_name = img_file_name
        self.img = Image(img_file_name)

        self.texts = []
        self.tables = []

        self.rectangles = []
        self.lines = []

        self.input_grouping = []

    def text_detection(self):
        if self.detection_method == 'Baidu':
            self.Baidu_OCR_text_detection()
        elif self.detection_method == 'Google':
            self.Google_OCR_text_detection()
        else:
            print('Please choose a detection method from Google and Baidu')

    def Google_OCR_text_detection(self):
        url = 'https://vision.googleapis.com/v1/images:annotate'
        api_key = 'AIzaSyAxjrH4Me8dQCC6BTtxHFcUphWHPNR2VGQ'
        start = time.clock()
        detection_results = OCR.request_Google_OCR(url,api_key,self.img_file_name)
        for result in detection_results:
            x_coordinate = []
            y_coordinate = []
            text_location = result['boundingPoly']['vertices']
            text = result['description']
            for index in text_location:
                x_coordinate.append(index['x'])
                y_coordinate.append(index['y'])
            top = min(y_coordinate)
            left = min(x_coordinate)
            width = max(x_coordinate) - min(x_coordinate)
            height = max(y_coordinate) - min(y_coordinate)
            location = {'width': width, 'top': top, 'left': left, 'height': height}
            self.texts.append(Text(text, location))
        print('*** Google_OCR Processing Time:%.3f s***' % (time.clock() - start))
        print(len(self.texts))

    def Baidu_OCR_text_detection(self):
        start = time.clock()
        detection_result = OCR.ocr_detection(self.img_file_name)
        texts = detection_result['words_result']
        for text in texts:
            self.texts.append(Text(text['words'], text['location']))
        print('*** OCR Processing Time:%.3f s***' % (time.clock() - start))
        print(len(self.texts))

    def element_detection(self):
        start = time.clock()
        self.rectangles = self.img.detect_rectangle_elements()
        self.lines = self.img.detect_line_elements()
        print('*** Element Detection Time:%.3f s***' % (time.clock() - start))
        print(len(self.rectangles))

    def detect_insection(self):
        for rec in self.rectangles:
            rec_top_left = [rec.location['top'],rec.location['left']]
            rec_bottom_right = [rec.location['bottom'],rec.location['right']]
            for text in self.texts:
                text_top_left = [text.location['top'],text.location['left']]
                text_bottom_right = [text.location['top'] + text.location['height'], text.location['left'] + text.location['width']]
                if rec_top_left[0] - text_top_left[0] < 5 and rec_top_left[1] - text_top_left[1] < 5 and rec_bottom_right[0] - text_bottom_right[0] > -5 and rec_bottom_right[1] - text_bottom_right[1] > -5:
                    rec.Is_Inserted_Text = True
        for rec in self.rectangles:
            if rec.Is_Inserted_Text == True:
                print(rec)

    def input_grouping_detection(self):
        print(self.texts[0].location)
        print(self.rectangles[0].location)
        for text in self.texts:
            text_top_left = [text.location['top'], text.location['left']]
            text_bottom_right = [text.location['top'] + text.location['height'],
                                 text.location['left'] + text.location['width']]
            for rec in self.rectangles:
                rec_top_left = [rec.location['top'], rec.location['left']]
                rec_bottom_right = [rec.location['bottom'], rec.location['right']]
                if abs(text_top_left[0] - rec_top_left[0]) < 5 and abs(text_bottom_right[1] - rec_top_left[1]) < 40:
                    input_group = (text,rec,[(text_top_left[1],text_top_left[0]),(rec_bottom_right[1],rec_bottom_right[0])])
                    self.input_grouping.append(input_group)
                if abs(text_bottom_right[0]-rec_top_left[0]) < 5 and abs(text_top_left[1] - rec_top_left[1]) < 40:
                    Is_Isolated = True
                    for new_text in self.texts:
                        new_text_top_left = [new_text.location['top'], new_text.location['left']]
                        new_text_bottom_right = [new_text.location['top'] + new_text.location['height'],
                                             new_text.location['left'] + new_text.location['width']]
                        if abs(new_text_top_left[0] - rec_top_left[0]) < 5 and abs(new_text_bottom_right[1] - rec_top_left[1]) < 40:
                            Is_Isolated = False
                    if Is_Isolated == True:
                        input_group = (text, rec, [(text_top_left[1], text_top_left[0]), (rec_bottom_right[1], rec_bottom_right[0])])
                        self.input_grouping.append(input_group)


    def visualize(self):
        board = self.img.img.copy()
        for text in self.texts:
            loc = text.location
            cv2.rectangle(board, (loc['left'], loc['top']), (loc['left'] + loc['width'], loc['top'] + loc['height']), (255, 0, 0), 1)

        for rec in self.rectangles:
            loc = rec.location
            if rec.Is_Inserted_Text == True:
                cv2.rectangle(board, (loc['left'], loc['top']), (loc['right'], loc['bottom']), (0, 255, 0), 3)
            else:
                cv2.rectangle(board, (loc['left'], loc['top']), (loc['right'], loc['bottom']), (0, 0, 255), 1)

        for line in self.lines:
            loc = line.location
            cv2.rectangle(board, (loc['left'], loc['top']), (loc['right'], loc['bottom']), (0, 0, 255), 1)

        for input_group in self.input_grouping:
            loc_left_top = input_group[2][0]
            loc_right_bottom = input_group[2][1]
            cv2.rectangle(board, loc_left_top, loc_right_bottom, (0, 0, 255), 4)

        cv2.imshow('form', board)
        cv2.waitKey()
        cv2.destroyAllWindows()
